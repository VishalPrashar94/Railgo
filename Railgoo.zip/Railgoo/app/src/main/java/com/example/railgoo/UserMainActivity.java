package com.example.railgoo;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.PopupMenu;

public class UserMainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_main);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.main_menu , menu);

        return  true;

    }

    public boolean onOptionsItemSelected(MenuItem item) {

        if(item.getItemId() == R.id.profile)
        {
            startActivity(new Intent(UserMainActivity.this , ProfileActivity.class));

        }
        return true;
    }

    public void search_train(View view) {

        Intent i = new Intent(UserMainActivity.this , SearchTrain.class);

        startActivity(i);
    }

    public void book_ticket(View view) {

        Intent i = new Intent(UserMainActivity.this , BookingActivity.class);

        startActivity(i);

    }

    public void view_booking(View view) {

        Intent i = new Intent(UserMainActivity.this , ViewBookings.class);

        startActivity(i);
    }
}
