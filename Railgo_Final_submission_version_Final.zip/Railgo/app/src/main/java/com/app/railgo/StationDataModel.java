package com.app.railgo;

public class StationDataModel {

    private String name , location;

    private int id;

    public StationDataModel()
    {

    }

    public String getLocation() {
        return location;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setId(int id) {
        this.id = id;
    }

}
