package com.app.railgo;

import android.app.ProgressDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class AddTrain extends AppCompatActivity {


    private Spinner departureSpinner ;

    private Spinner destinationSpinner ;

    private List<StationDataModel> station_list ;

    private TextView departure_time , destination_time ;

    private EditText train_name_et , available_seats_et ;

    private ProgressDialog pd ;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_add_train);

        getSupportActionBar().setTitle("Add Train");

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        getSupportActionBar().setDisplayShowHomeEnabled(true);

        station_list = new ArrayList<>();

        departureSpinner = findViewById(R.id.departure_station_spinner);

        destinationSpinner = findViewById(R.id.destination_station_spinner);

        departure_time = findViewById(R.id.departure_time);

        destination_time = findViewById(R.id.destination_time);

        train_name_et = findViewById(R.id.train_name_et);

        available_seats_et = findViewById(R.id.available_seats);

        pd = new ProgressDialog(this);

        pd.setMessage("Please wait..");

        pd.setTitle("Loading");


        get_stations();
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if(item.getItemId() == android.R.id.home)
        {
            finish();
        }

        return super.onOptionsItemSelected(item);
    }


    private void get_stations()
    {

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest("http://"+getString(R.string.ip_address)+"/railgo/get_station.php", new JSONObject(), new Response.Listener<JSONObject>()
        {
            @Override
            public void onResponse(JSONObject response) {

                System.out.println(response);


                try {
                    if(response.getString("key").equalsIgnoreCase("successfull"))
                    {
                        JSONArray jsonArray = response.getJSONArray("data");

                        station_list.clear();

                        for(int i= 0; i<jsonArray.length(); i++)
                        {

                            JSONObject jsonObject = jsonArray.getJSONObject(i);

                            StationDataModel dataModel = new StationDataModel();

                            dataModel.setName(jsonObject.getString("name"));
                            dataModel.setLocation(jsonObject.getString("location"));
                            dataModel.setId(jsonObject.getInt("stationId"));

                            station_list.add(dataModel);


                        }

                        departureSpinner.setAdapter(new spinnerAdapter(AddTrain.this , R.layout.spinner_layout , station_list));

                        destinationSpinner.setAdapter(new spinnerAdapter(AddTrain.this , R.layout.spinner_layout , station_list));


                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                System.out.println(error);


            }
        });


        Volley.newRequestQueue(AddTrain.this).add(jsonObjectRequest);



    }

    public void select_destination_time(View view) {

        Calendar mcurrentTime = Calendar.getInstance();
        int hour = mcurrentTime.get(Calendar.HOUR_OF_DAY);
        int minute = mcurrentTime.get(Calendar.MINUTE);
        TimePickerDialog mTimePicker;
        mTimePicker = new TimePickerDialog(AddTrain.this, new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker timePicker, int selectedHour, int selectedMinute) {

                destination_time.setText( selectedHour + ":" + selectedMinute);
            }
        }, hour, minute, true);//Yes 24 hour time
        mTimePicker.setTitle("Select Time");
        mTimePicker.show();


    }

    public void select_departure_time(View view) {

        Calendar mcurrentTime = Calendar.getInstance();
        int hour = mcurrentTime.get(Calendar.HOUR_OF_DAY);
        int minute = mcurrentTime.get(Calendar.MINUTE);
        TimePickerDialog mTimePicker;
        mTimePicker = new TimePickerDialog(AddTrain.this, new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker timePicker, int selectedHour, int selectedMinute) {

                departure_time.setText( selectedHour + ":" + selectedMinute);
            }
        }, hour, minute, true);//Yes 24 hour time
        mTimePicker.setTitle("Select Time");
        mTimePicker.show();


    }


    public void add_train(View view) {


        String train_name = train_name_et.getText().toString();

        String available_seats = available_seats_et.getText().toString();

        if(train_name.trim().equals(""))
        {
            Toast.makeText(AddTrain.this , "Please enter train name" , Toast.LENGTH_SHORT).show();

            return;
        }

        StationDataModel departureStationData = (StationDataModel) departureSpinner.getSelectedItem();

        String departureStationName = departureStationData.getName();

        int departureSationId = departureStationData.getId();

        StationDataModel destinationStationData = (StationDataModel) destinationSpinner.getSelectedItem();

        String destinationStationName = destinationStationData.getName();

        int destinationStationId = destinationStationData.getId();

        String departureTime = departure_time.getText().toString().trim();

        String destinationTime = destination_time.getText().toString().trim();



        if( departureTime.equalsIgnoreCase("Select time") )
        {
            Toast.makeText(AddTrain.this , "Please select departure time" , Toast.LENGTH_SHORT).show();

            return;
        }

        if( destinationTime.equalsIgnoreCase("Select time") )
        {
            Toast.makeText(AddTrain.this , "Please select destination time" , Toast.LENGTH_SHORT).show();

            return;
        }

        if(available_seats.trim().equalsIgnoreCase(""))
        {
            Toast.makeText(AddTrain.this , "Please enter available seats" , Toast.LENGTH_SHORT).show();

            return;
        }


        JSONObject jsonObject = new JSONObject();

        try {

            jsonObject.put("train_name" , train_name);
            jsonObject.put("departureStationName" , departureStationName);
            jsonObject.put("departureStationId" , departureSationId);
            jsonObject.put("destinationStationName" , destinationStationName);
            jsonObject.put("destinationStationId" , destinationStationId);
            jsonObject.put("departureTime" , departureTime);
            jsonObject.put("destinationTime" , destinationTime);
            jsonObject.put("availableSeats" , available_seats);

        } catch (JSONException e) {
            e.printStackTrace();
        }


        System.out.println(jsonObject);


        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest("http://"+getString(R.string.ip_address)+"/railgo/add_train.php", jsonObject, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {

                pd.dismiss();
                System.out.println(response);

                try {
                    if(response.getString("key").equalsIgnoreCase("successfull"))
                    {
                        Toast.makeText(AddTrain.this , "Train added successfully" , Toast.LENGTH_SHORT).show();

                        finish();

                    }

                    else {

                        Toast.makeText(AddTrain.this , "Error try again" , Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                pd.dismiss();
                System.out.println(error);

                Toast.makeText(AddTrain.this , "network error" , Toast.LENGTH_SHORT).show();

            }
        });

        Volley.newRequestQueue(AddTrain.this).add(jsonObjectRequest);


    }


}
