package com.app.railgo;

import android.app.ProgressDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Calendar;

public class AddStation extends AppCompatActivity {

    private EditText station_name_et , station_location_et ;

    private ProgressDialog pd ;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_station);

        getSupportActionBar().setTitle("Add Station");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        station_name_et = findViewById(R.id.station_name_et);

        station_location_et = findViewById(R.id.station_location_et);

        pd = new ProgressDialog(this);

        pd.setMessage("Please wait..");

        pd.setTitle("Loading");



    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if(item.getItemId() == android.R.id.home)
        {
            finish();
        }

        return super.onOptionsItemSelected(item);
    }

    public void add_station(View view) {

        String station_name = station_name_et.getText().toString();

        String station_location = station_location_et.getText().toString();

        if(station_name.trim().equals("") || station_location.trim().equals(""))
        {
            Toast.makeText(AddStation.this , "please fill all fields" , Toast.LENGTH_SHORT).show();

            return;
        }

        pd.show();

        JSONObject jsonObject = new JSONObject();

        try {
            jsonObject.put("name" , station_name);
            jsonObject.put("location" , station_location);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest("http://"+getString(R.string.ip_address)+"/railgo/add_station.php", jsonObject, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {

                pd.dismiss();
                System.out.println(response);

                try {
                    if(response.getString("key").equalsIgnoreCase("successfull"))
                    {
                        Toast.makeText(AddStation.this , "Station added successfully" , Toast.LENGTH_SHORT).show();

                       finish();

                    }

                    else {

                        Toast.makeText(AddStation.this , "error try again" , Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                pd.dismiss();
                System.out.println(error);


                Toast.makeText(AddStation.this , "network error" , Toast.LENGTH_SHORT).show();

            }
        });

        Volley.newRequestQueue(AddStation.this).add(jsonObjectRequest);


    }



}
