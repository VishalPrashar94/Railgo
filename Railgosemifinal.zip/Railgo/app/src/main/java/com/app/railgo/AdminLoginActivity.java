package com.app.railgo;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class AdminLoginActivity extends AppCompatActivity {


    private EditText email_et , password_et;

    private ProgressDialog pd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_login);

        email_et = findViewById(R.id.email_et);

        password_et = findViewById(R.id.password_et);

        pd = new ProgressDialog(this);

        pd.setMessage("Please wait..");
        pd.setTitle("Loading");

    }

    public void do_login(View view) {

        String email = email_et.getText().toString();

        String password = password_et.getText().toString();

        if( ! Patterns.EMAIL_ADDRESS.matcher(email).matches() )

        {
            Toast.makeText(AdminLoginActivity.this , "Please check your email syntax" , Toast.LENGTH_SHORT).show();

            return;
        }

        if( password.length() < 8 )
        {

            Toast.makeText(AdminLoginActivity.this , "Password must be atleast 8 characters long" , Toast.LENGTH_SHORT).show();

            return;

        }

        pd.show();

        JSONObject jsonObject = new JSONObject();

        try {
            jsonObject.put("email_key" , email);
            jsonObject.put("pass_key" , password);

        } catch (JSONException e) {
            e.printStackTrace();
        }

        System.out.println(jsonObject);


        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest("http://"+getString(R.string.ip_address)+"/railgo/admin_login.php", jsonObject, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {

                pd.dismiss();
                System.out.println(response);

                try {
                    if(response.getString("key").equalsIgnoreCase("successfull"))
                    {
                        Toast.makeText(AdminLoginActivity.this , "Logged in successfully" , Toast.LENGTH_SHORT).show();

                        Intent i = new Intent(AdminLoginActivity.this , AdminMainActivity.class);

                        startActivity(i);

                    }

                    else {

                        Toast.makeText(AdminLoginActivity.this , "invalid credentials try again" , Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                pd.dismiss();
                System.out.println(error);

                Toast.makeText(AdminLoginActivity.this , "network error" , Toast.LENGTH_SHORT).show();

            }
        });

        Volley.newRequestQueue(AdminLoginActivity.this).add(jsonObjectRequest);


    }
}
