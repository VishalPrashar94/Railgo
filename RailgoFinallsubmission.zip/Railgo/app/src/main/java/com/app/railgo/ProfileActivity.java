package com.app.railgo;

import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Patterns;
import android.view.MenuItem;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.util.Calendar;

public class ProfileActivity extends AppCompatActivity {

    private TextView date_txt;

    private EditText name_et , email_et , phone_et ;

    private ProgressDialog pd;

    private RadioGroup gender_radio_group ;

    String uname,uemail,uphone;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        getSupportActionBar().setTitle("Profile");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        date_txt = findViewById(R.id.date_txt);

        name_et = findViewById(R.id.name_et);
        email_et = findViewById(R.id.email_et);
        phone_et = findViewById(R.id.phone_et);



        pd = new ProgressDialog(this);

        pd.setMessage("Please wait..");

        pd.setTitle("Loading");

        new MyTask().execute();

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if(item.getItemId() == android.R.id.home)
        {
            finish();
        }

        return super.onOptionsItemSelected(item);
    }

    public void save(View view) {

        uname = name_et.getText().toString();

        uemail = email_et.getText().toString();

        uphone = phone_et.getText().toString();



        if (uname.trim().equals("")) {
            Toast.makeText(ProfileActivity.this, "Name cannot be empty.", Toast.LENGTH_SHORT).show();

            return;
        }

        if (!Patterns.EMAIL_ADDRESS.matcher(uemail).matches()) {
            Toast.makeText(ProfileActivity.this, "Invalid email syntax.", Toast.LENGTH_SHORT).show();

            return;

        }

        if (uphone.length() < 10) {
            Toast.makeText(ProfileActivity.this, "Invalid phone number.", Toast.LENGTH_SHORT).show();

            return;

        }


        pd.show();
        new MyTask2().execute();
    }
//
//    public void select_date(View view) {
//
//        final Calendar c = Calendar.getInstance();
//        int mYear = c.get(Calendar.YEAR);
//        int mMonth = c.get(Calendar.MONTH);
//        int  mDay = c.get(Calendar.DAY_OF_MONTH);
//
//        // Launch Date Picker Dialog
//        DatePickerDialog dpd = new DatePickerDialog(ProfileActivity.this,
//                new DatePickerDialog.OnDateSetListener() {
//
//                    @Override
//                    public void onDateSet(DatePicker view, int year,
//                                          int monthOfYear, int dayOfMonth) {
//                        // Display Selected date in textbox
//                        date_txt.setText(year + "-" + (monthOfYear + 1) + "-" + dayOfMonth   );
//
//                    }
//                }, mYear, mMonth, mDay);
//
//        dpd.getDatePicker().setMaxDate(System.currentTimeMillis());
//
//        dpd.show();
//    }


    private class MyTask extends AsyncTask<Void, Void, Void> {

        String user_status, username, phone;

        public String getUser_status() {
            return user_status;
        }

        public void setUser_status(String user_status) {
            this.user_status = user_status;
        }

        Datamodel dtmodel = Datamodel.getInstance();
        @Override

        protected Void doInBackground(Void... params) {



            URL url = null;

            try {

                url = new URL("http://192.168.1.19:8080/railgo/webresources/generic/user_Profile&" + dtmodel.getEmail());

                HttpURLConnection client = null;

                client = (HttpURLConnection) url.openConnection();

                client.setRequestMethod("GET");

                int responseCode = client.getResponseCode();

                System.out.println("\n Sending 'GET' request to URL : " + url);

                System.out.println("Response Code : " + responseCode);

                InputStreamReader myInput = new InputStreamReader(client.getInputStream());

                BufferedReader in = new BufferedReader(myInput);
                String inputLine;
                StringBuffer response = new StringBuffer();

                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
                in.close();

                //print result
                System.out.println(response.toString());

                JSONObject obj = new JSONObject(response.toString());

                user_status = obj.getString("Status");
                setUser_status(user_status);

                username = obj.getString("USERNAME");
                phone = obj.getString("CONTACTNUMBER");

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (ProtocolException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();

            }

            return null;

        }


        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);

            if(getUser_status().equals("OK")) {
                name_et.setText(username);
                email_et.setText(dtmodel.getEmail());
                phone_et.setText(phone);
            }

        }


    }



    private class MyTask2 extends AsyncTask<Void, Void, Void> {

        String user_status, username, phone;

        public String getUser_status() {
            return user_status;
        }

        public void setUser_status(String user_status) {
            this.user_status = user_status;
        }

        Datamodel dtmodel = Datamodel.getInstance();
        @Override

        protected Void doInBackground(Void... params) {



            URL url = null;

            try {

                url = new URL("http://192.168.1.19:8080/railgo/webresources/generic/update&" + dtmodel.getUser_id()+"&"+uname+"&"+uphone+"&"+uemail);

                HttpURLConnection client = null;

                client = (HttpURLConnection) url.openConnection();

                client.setRequestMethod("GET");

                int responseCode = client.getResponseCode();

                System.out.println("\n Sending 'GET' request to URL : " + url);

                System.out.println("Response Code : " + responseCode);

                InputStreamReader myInput = new InputStreamReader(client.getInputStream());

                BufferedReader in = new BufferedReader(myInput);
                String inputLine;
                StringBuffer response = new StringBuffer();

                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
                in.close();

                //print result
                System.out.println(response.toString());

                JSONObject obj = new JSONObject(response.toString());

                user_status = obj.getString("Status");
                setUser_status(user_status);

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (ProtocolException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();

            }

            return null;

        }


        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);

            if(getUser_status().equals("OK")) {
                name_et.setText(uname);
                email_et.setText(uemail);
                phone_et.setText(uphone);
                pd.cancel();

                Intent intent=new Intent(getApplicationContext(),ProfileActivity.class);
                startActivity(intent);
            }

        }


    }
}
