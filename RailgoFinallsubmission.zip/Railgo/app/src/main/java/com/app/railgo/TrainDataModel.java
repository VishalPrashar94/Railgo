package com.app.railgo;

public class TrainDataModel {


    private String name , departure_station , destination_station, departureTime, destinationTime ;

    private int number , seats , stationId;

    public String getDepartureTime() {
        return departureTime;
    }

    public void setDepartureTime(String departureTime) {
        this.departureTime = departureTime;
    }

    public String getDestinationTime() {
        return destinationTime;
    }

    public void setDestinationTime(String destinationTime) {
        this.destinationTime = destinationTime;
    }

    public TrainDataModel(String departure_station, String destination_station, int number) {
        this.departure_station = departure_station;
        this.destination_station = destination_station;
        this.number = number;
    }

    public TrainDataModel()
    {

    }

    public void setStationId(int stationId) {
        this.stationId = stationId;
    }

    public int getStationId() {
        return stationId;
    }

    public void setDeparture_station(String departure_station) {
        this.departure_station = departure_station;
    }

    public void setDestination_station(String destination_station) {
        this.destination_station = destination_station;
    }

    public String getDeparture_station() {
        return departure_station;
    }

    public String getDestination_station() {
        return destination_station;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public void setSeats(int seats) {
        this.seats = seats;
    }

    public String getName() {
        return name;
    }

    public int getNumber() {
        return number;
    }

    public int getSeats() {
        return seats;
    }

}
