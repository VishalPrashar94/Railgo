package com.app.railgo;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class ViewBookings extends AppCompatActivity {


    private List<BookingDataModel> booking_list;

    private RecyclerView booking_recycler;
    public Button cancel_booking_btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_bookings);

        getSupportActionBar().setTitle("View Booking");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        booking_list = new ArrayList<>();
        //cancel_booking_btn = findViewById(R.id.btn_cancelBooking);

        booking_recycler = findViewById(R.id.booking_recycler);

        booking_recycler.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));

        new MyTask().execute();

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if (item.getItemId() == android.R.id.home) {
            finish();
        }

        return super.onOptionsItemSelected(item);
    }

    private class MyTask extends AsyncTask<Void, Void, Void> {

        String user_status;

        public String getUser_status() {
            return user_status;
        }

        public void setUser_status(String user_status) {
            this.user_status = user_status;
        }

        JSONArray jsonArray;

        @Override
        protected Void doInBackground(Void... params) {


            Datamodel datamodel = Datamodel.getInstance();


            URL url = null;

            try {

                url = new URL("http://192.168.1.19:8080/railgo/webresources/generic/Bookings&" + datamodel.getUser_id());

                HttpURLConnection client = null;

                client = (HttpURLConnection) url.openConnection();

                client.setRequestMethod("GET");

                int responseCode = client.getResponseCode();

                System.out.println("\n Sending 'GET' request to URL : " + url);

                System.out.println("Response Code : " + responseCode);

                InputStreamReader myInput = new InputStreamReader(client.getInputStream());

                BufferedReader in = new BufferedReader(myInput);
                String inputLine;
                StringBuffer response = new StringBuffer();

                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
                in.close();

                //print result
                System.out.println(response.toString());

                JSONObject obj = new JSONObject(response.toString());

                jsonArray = obj.getJSONArray("DATA");
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        booking_list.clear();

                        for (int i = 0; i < jsonArray.length(); i++) {
                            BookingDataModel dataModel = new BookingDataModel();

                            JSONObject jsonObject = null;
                            try {
                                jsonObject = jsonArray.getJSONObject(i);


                                dataModel.setDate(jsonObject.getString("BookingDate"));
                                dataModel.setFromStation(jsonObject.getString("FromStation"));
                                dataModel.setToStation(jsonObject.getString("ToStation"));
                                dataModel.setEmail(jsonObject.getString("Email"));
                                dataModel.setNumberPassengers(jsonObject.getString("NumberOfPassengers"));
                                dataModel.setPassengerNames(jsonObject.getString("passengerNames"));
                                dataModel.setTrainNumber(jsonObject.getString("TrainNumber"));
                                dataModel.setBookingid(jsonObject.getString("bookingid"));
                                dataModel.setStatus(jsonObject.getString("status"));
                                if(dataModel.getStatus().equals("Cancel")){
                                   // cancel_booking_btn.setVisibility(View.GONE);
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }


                            booking_list.add(dataModel);

                        }


                        booking_recycler.setAdapter(new Adapter());
                    }
                });


            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (ProtocolException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();

            }

            return null;

        }


        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);

        }

    }


    private class ViewHolder extends RecyclerView.ViewHolder {

        private TextView booking_id, booking_date, fromStation, toStation, train_number, num_passenger, passenger_names, status;



        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            booking_date = itemView.findViewById(R.id.booking_date);
            fromStation = itemView.findViewById(R.id.from_station);
            toStation = itemView.findViewById(R.id.to_station);
            train_number = itemView.findViewById(R.id.train_number);
            num_passenger = itemView.findViewById(R.id.num_passenger);
            passenger_names = itemView.findViewById(R.id.passenger_names);
            booking_id = itemView.findViewById(R.id.booking_id);
            cancel_booking_btn = itemView.findViewById(R.id.btn_cancelBooking);


            status = itemView.findViewById(R.id.status_id);

            cancel_booking_btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    new MyTask3().execute();
                }
            });


        }
    }

    private class Adapter extends RecyclerView.Adapter<ViewHolder> {

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
            return new ViewHolder(LayoutInflater.from(ViewBookings.this).inflate(R.layout.booking_cell, viewGroup, false));
        }

        int book;
        @Override
        public void onBindViewHolder(@NonNull ViewHolder viewHolder, int i) {


            final BookingDataModel dataModel = booking_list.get(i);


            viewHolder.booking_date.setText(dataModel.getDate());
            viewHolder.fromStation.setText(dataModel.getFromStation());
            viewHolder.toStation.setText(dataModel.getToStation());
            viewHolder.train_number.setText(dataModel.getTrainNumber());
            viewHolder.num_passenger.setText(dataModel.getNumberPassengers());
            viewHolder.passenger_names.setText(dataModel.getPassengerNames());
            viewHolder.booking_id.setText(dataModel.getBookingid());
            viewHolder.status.setText(dataModel.getStatus());


            viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    dtmodel.setBooking_id(Integer.parseInt(dataModel.getBookingid()));
                    System.out.println(dtmodel.getBooking_id());
                }
            });


        }

        @Override
        public int getItemCount() {
            return booking_list.size();
        }
    }

    Datamodel dtmodel = Datamodel.getInstance();
    private class MyTask3 extends AsyncTask<Void, Void, Void> {

        String user_status;

        public String getUser_status() {
            return user_status;
        }

        public void setUser_status(String user_status) {
            this.user_status = user_status;
        }





        @Override

        protected Void doInBackground(Void... params) {


            URL url = null;

            try {

                url = new URL("http://192.168.1.19:8080/railgo/webresources/generic/Booking&"+dtmodel.getBooking_id() );

                HttpURLConnection client = null;

                client = (HttpURLConnection) url.openConnection();

                client.setRequestMethod("GET");

                int responseCode = client.getResponseCode();

                System.out.println("\n Sending 'GET' request to URL : " + url);

                System.out.println("Response Code : " + responseCode);

                InputStreamReader myInput = new InputStreamReader(client.getInputStream());

                BufferedReader in = new BufferedReader(myInput);
                String inputLine;
                StringBuffer response = new StringBuffer();

                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
                in.close();

                //print result
                System.out.println(response.toString());

                JSONObject obj = new JSONObject(response.toString());

                user_status = obj.getString("STATUS");
                setUser_status(user_status);

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (ProtocolException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();

            }

            return null;

        }


        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);

            Intent intent=new Intent(getApplicationContext(),ViewBookings.class);
            Toast.makeText(getApplicationContext(),"BOOKING IS SUCCESSFULLY CANCEL",Toast.LENGTH_LONG).show();

            startActivity(intent);
        }

    }
}
