package com.app.railgo;

import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class BookingActivity extends AppCompatActivity {

    private Spinner train_number_spinner;

    private List<TrainDataModel> train_list ;

    private List<String> train_number;

    private EditText departure_station_et , destination_station_et , num_passenger_et , passenger_names_et , coach_number_et;

    private TextView select_date_txt;

    String depstation, deststation, num_passenger, passenger_names, coach_number,selected_date;
    int trainnumber, stationid;

    private int selected_index = 0;

    private ProgressDialog pd ;
    ArrayAdapter<String> adapter;
    String trainNumber[];


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_booking);

        getSupportActionBar().setTitle("Book ticket");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        pd = new ProgressDialog(this);

        pd.setMessage("Please wait..");

        pd.setTitle("Loading");


        train_number_spinner = findViewById(R.id.train_number_spinner);

        departure_station_et = findViewById(R.id.departure_station_et);

        destination_station_et = findViewById(R.id.destination_station_et);

        select_date_txt = findViewById(R.id.date_txt);

        num_passenger_et = findViewById(R.id.num_passenger_et);

        passenger_names_et = findViewById(R.id.passenger_name_et);

        coach_number_et = findViewById(R.id.coach_number_et);

        train_list = new ArrayList<>();

        train_number = new ArrayList<>();


         adapter = new ArrayAdapter<String>(BookingActivity.this,
                android.R.layout.simple_list_item_1,train_number);



        new MyTask().execute();



    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if(item.getItemId() == android.R.id.home)
        {
            finish();
        }

        return super.onOptionsItemSelected(item);
    }


    private class MyTask extends AsyncTask<Void, Void, Void> {

        String user_status;
        JSONArray jsonarray;

        public String getUser_status() {
            return user_status;
        }

        public void setUser_status(String user_status) {
            this.user_status = user_status;
        }





        @Override

        protected Void doInBackground(Void... params) {


            URL url = null;

            try {

                url = new URL("http://192.168.1.19:8080/railgo/webresources/generic/trains");

                HttpURLConnection client = null;

                client = (HttpURLConnection) url.openConnection();

                client.setRequestMethod("GET");

                int responseCode = client.getResponseCode();

                System.out.println("\n Sending 'GET' request to URL : " + url);

                System.out.println("Response Code : " + responseCode);

                InputStreamReader myInput = new InputStreamReader(client.getInputStream());

                BufferedReader in = new BufferedReader(myInput);
                String inputLine;
                StringBuffer response = new StringBuffer();

                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
                in.close();

                //print result
                System.out.println(response.toString());

                JSONObject obj = new JSONObject(response.toString());
                jsonarray=obj.getJSONArray("DATA");
                 String[] tempjson ;


                final String[] finalTempjson = new String[jsonarray.length()+1];
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {


                        TrainDataModel dataModel = new TrainDataModel();

                        TrainDataModel dataModel1;
                        JSONObject jsonObject1 = null;
                for (int i = 0; i < jsonarray.length(); i++) {

                    try {
                        jsonObject1 = jsonarray.getJSONObject(i);
                        dataModel.setName(jsonObject1.getString("TrainName"));

                        dataModel.setNumber(jsonObject1.getInt("TrainNumber"));

                        dataModel.setSeats(jsonObject1.getInt("availableseats"));

                        dataModel.setDeparture_station(jsonObject1.getString("departurestation"));

                        dataModel.setDestination_station(jsonObject1.getString("destinationstation"));

                        dataModel.setDepartureTime(jsonObject1.getString("departuretime"));

                        dataModel.setDestinationTime(jsonObject1.getString("destinationtime"));

                    dataModel.setStationId(jsonObject1.getInt("station_id"));


                        train_list.add(new TrainDataModel(jsonObject1.getString("departurestation"),jsonObject1.getString("destinationstation"),jsonObject1.getInt("TrainNumber")));

                        finalTempjson[i] =String.valueOf(jsonObject1.getInt("TrainNumber"));



                        train_number.add(finalTempjson[i]);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }



                }
                        System.out.println(train_list.get(0).getDeparture_station());
                System.out.println(train_list.get(1).getDeparture_station());

                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                train_number_spinner.setAdapter(adapter);
                train_number_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int selected_index, long id) {

                        selected_index = selected_index;

                       // int i;
                        trainnumber=train_list.get(selected_index).getNumber();
                        depstation=train_list.get(selected_index).getDeparture_station();
                        deststation=train_list.get(selected_index).getDestination_station();

                        stationid=train_list.get(selected_index).getStationId();

                        departure_station_et.setText(train_list.get(selected_index).getDeparture_station());

                        destination_station_et.setText(train_list.get(selected_index).getDestination_station());

                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {

                    }
                });

                if (train_list.size() > 0) {
                    departure_station_et.setText(train_list.get(0).getDeparture_station());

                    destination_station_et.setText(train_list.get(0).getDestination_station());
                }

                    }
                });

            } catch (Exception e) {
                System.out.println(e.getMessage());


            }
            return null;
        }
        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);



        }

    }




    public void select_date(View view) {

        final Calendar c = Calendar.getInstance();
        int mYear = c.get(Calendar.YEAR);
        int mMonth = c.get(Calendar.MONTH);
        int  mDay = c.get(Calendar.DAY_OF_MONTH);

        // Launch Date Picker Dialog
        DatePickerDialog dpd = new DatePickerDialog(BookingActivity.this,
                new DatePickerDialog.OnDateSetListener() {

                    @Override
                    public void onDateSet(DatePicker view, int year,
                                          int monthOfYear, int dayOfMonth) {
                        // Display Selected date in textbox
                        select_date_txt.setText(year + "-"
                                + (monthOfYear + 1) + "-" + dayOfMonth   );

                    }
                }, mYear, mMonth, mDay);
        dpd.show();
    }





    public void book_ticket(View view) {

         num_passenger = num_passenger_et.getText().toString();

         passenger_names = passenger_names_et.getText().toString();

         coach_number = coach_number_et.getText().toString();

         selected_date = select_date_txt.getText().toString();

        TrainDataModel dataModel = train_list.get(selected_index);

        if(num_passenger.trim().equalsIgnoreCase(""))
        {
            Toast.makeText(BookingActivity.this ,"please enter passenger number", Toast.LENGTH_SHORT).show();

            return;
        }

        if(passenger_names.trim().equalsIgnoreCase(""))
        {
            Toast.makeText(BookingActivity.this ,"please enter passenger name", Toast.LENGTH_SHORT).show();

            return;
        }

        if(coach_number.trim().equalsIgnoreCase(""))
        {
            Toast.makeText(BookingActivity.this ,"please enter coach number", Toast.LENGTH_SHORT).show();

            return;
        }

        if(selected_date.trim().equalsIgnoreCase("Select date"))
        {
            Toast.makeText(BookingActivity.this ,"please select date", Toast.LENGTH_SHORT).show();

            return;
        }
//        if(selected_date.compareToIgnoreCase()
//        {
//            Toast.makeText(BookingActivity.this ,"please select date", Toast.LENGTH_SHORT).show();
//
//            return;
//        }


        pd.show();


        new MyTask2().execute();




    }


    private class MyTask2 extends AsyncTask<Void, Void, Void> {

        String user_status;
        JSONArray jsonarray;
        Datamodel dtmodel = Datamodel.getInstance();


        public String getUser_status() {
            return user_status;
        }

        public void setUser_status(String user_status) {
            this.user_status = user_status;
        }





        @Override

        protected Void doInBackground(Void... params) {


            URL url = null;

            try {

                url = new URL("http://192.168.1.19:8080/railgo/webresources/generic/booking&"+dtmodel.getEmail()+"&"+depstation+"&"+deststation+"&"+selected_date+"&"+coach_number+"&"+num_passenger+"&"+dtmodel.getUser_id()+"&"+stationid+"&"+trainnumber+"&Active&"+passenger_names+"");

                HttpURLConnection client = null;

                client = (HttpURLConnection) url.openConnection();

                client.setRequestMethod("GET");

                int responseCode = client.getResponseCode();

                System.out.println("\n Sending 'GET' request to URL : " + url);

                System.out.println("Response Code : " + responseCode);

                InputStreamReader myInput = new InputStreamReader(client.getInputStream());

                BufferedReader in = new BufferedReader(myInput);
                String inputLine;
                StringBuffer response = new StringBuffer();

                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
                in.close();

                //print result
                System.out.println(response.toString());

                JSONObject obj = new JSONObject(response.toString());
                setUser_status(obj.getString("STATUS"));

            } catch (Exception e) {
                System.out.println(e.getMessage());


            }
            return null;
        }
        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);


            if(getUser_status().equals("OK")){
                Intent intent=new Intent(getApplicationContext(),UserMainActivity.class);
                Toast.makeText(BookingActivity.this, "BOOKING SUCCESSFULL", Toast.LENGTH_LONG).show();
                pd.dismiss();

            }

        }

    }



}
