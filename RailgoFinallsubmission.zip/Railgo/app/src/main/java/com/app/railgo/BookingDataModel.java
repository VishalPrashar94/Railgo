package com.app.railgo;

public class BookingDataModel {

    private String email , fromStation , toStation , date , passengerNames , numberPassengers , trainNumber , bookingid , status, departuretime, destinationtime ;


    public BookingDataModel()
    {

    }

    public void setDate(String date) {
        this.date = date;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setFromStation(String fromStation) {
        this.fromStation = fromStation;
    }

    public void setNumberPassengers(String numberPassengers) {
        this.numberPassengers = numberPassengers;
    }

    public void setPassengerNames(String passengerNames) {
        this.passengerNames = passengerNames;
    }

    public void setToStation(String toStation) {
        this.toStation = toStation;
    }

    public String getDate() {
        return date;
    }

    public String getEmail() {
        return email;
    }

    public String getFromStation() {
        return fromStation;
    }

    public String getNumberPassengers() {
        return numberPassengers;
    }

    public String getPassengerNames() {
        return passengerNames;
    }

    public String getToStation() {
        return toStation;
    }

    public void setBookingid(String bookingid) {
        this.bookingid = bookingid;
    }

    public void setTrainNumber(String trainNumber) {
        this.trainNumber = trainNumber;
    }

    public String getBookingid() {
        return bookingid;
    }

    public String getTrainNumber() {
        return trainNumber;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getStatus() {
        return status;
    }

    public String getDeparturetime() {
        return departuretime;
    }

    public void setDeparturetime(String departuretime) {
        this.departuretime = departuretime;
    }
}
