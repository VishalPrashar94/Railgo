package com.app.railgo;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class FirstActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first);
    }

//    public void continue_admin(View view) {
//
//        Intent i = new Intent(FirstActivity.this , AdminLoginActivity.class);
//
//        i.putExtra("type","ADMIN");
//        startActivity(i);
//
//    }

    public void continue_user(View view) {

        Intent i = new Intent(FirstActivity.this , UserLoginActivity.class);

        i.putExtra("type","PASSENGER");
        startActivity(i);

    }
}
