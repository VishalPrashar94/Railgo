package com.app.railgo;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class SearchTrainResults extends AppCompatActivity {


    private List<TrainDataModel> train_list;

    private String departureStationId, destinationStationId;

    private RecyclerView train_recycler;
    JSONArray jsonArray;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_train_results);

        getSupportActionBar().setTitle("Search Results");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        train_recycler = findViewById(R.id.train_recycler);

        train_recycler.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));

        train_list = new ArrayList<>();

        departureStationId = getIntent().getStringExtra("departureStation");

        destinationStationId = getIntent().getStringExtra("destinationStation");

        new MyTask().execute();

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if (item.getItemId() == android.R.id.home) {
            finish();
        }

        return super.onOptionsItemSelected(item);
    }


    private class MyTask extends AsyncTask<Void, Void, Void> {
        int fulluid;
        String user_status;

        public String getUser_status() {
            return user_status;
        }

        public void setUser_status(String user_status) {
            this.user_status = user_status;
        }

        public int getFulluid() {
            return fulluid;
        }

        public void setFulluid(int fulluid) {
            this.fulluid = fulluid;
        }


        @Override

        protected Void doInBackground(Void... params) {


            URL url = null;

            try {

                url = new URL("http://192.168.0.138:8080/railgo/webresources/generic/searchTrain&" + departureStationId + "&" + destinationStationId);

                HttpURLConnection client = null;

                client = (HttpURLConnection) url.openConnection();

                client.setRequestMethod("GET");

                int responseCode = client.getResponseCode();

                System.out.println("\n Sending 'GET' request to URL : " + url);

                System.out.println("Response Code : " + responseCode);

                InputStreamReader myInput = new InputStreamReader(client.getInputStream());

                BufferedReader in = new BufferedReader(myInput);
                String inputLine;
                StringBuffer response = new StringBuffer();

                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
                in.close();

                //print result
                System.out.println(response.toString());


                JSONObject obj = new JSONObject(response.toString());

                 jsonArray = obj.getJSONArray("DATA");

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {

                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject jsonObject1 = null;
                            TrainDataModel dataModel = new TrainDataModel();
                            try {
                                jsonObject1 = jsonArray.getJSONObject(i);

                                dataModel.setName(jsonObject1.getString("name"));

                                dataModel.setNumber(jsonObject1.getInt("trainNumber"));

                                dataModel.setSeats(jsonObject1.getInt("availableSeats"));

                                dataModel.setDeparture_station(jsonObject1.getString("departureStation"));

                                dataModel.setDestination_station(jsonObject1.getString("destinationStation"));




                            } catch (JSONException e) {
                                e.printStackTrace();
                            }



                            train_list.add(dataModel);

                        }

                        train_recycler.setAdapter(new Adapter());


                    }
                });
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (ProtocolException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();

            }

            return null;

        }


        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);


        }


        private class ViewHolder extends RecyclerView.ViewHolder {

            private TextView name, number, seats, departureStation, destinationStation;

            public ViewHolder(@NonNull View itemView) {
                super(itemView);

                name = itemView.findViewById(R.id.train_name_txt);

                number = itemView.findViewById(R.id.train_number_txt);

                seats = itemView.findViewById(R.id.available_seats_txt);

                departureStation = itemView.findViewById(R.id.departureStation_txt);

                destinationStation = itemView.findViewById(R.id.destinationStation_txt);


            }
        }


        private class Adapter extends RecyclerView.Adapter<ViewHolder> {

            @NonNull
            @Override
            public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
                return new ViewHolder(LayoutInflater.from(SearchTrainResults.this).inflate(R.layout.train_cell, viewGroup, false));
            }

            @Override
            public void onBindViewHolder(@NonNull ViewHolder viewHolder, int i) {

                TrainDataModel dataModel = train_list.get(i);

                viewHolder.name.setText(dataModel.getName());

                viewHolder.number.setText(String.valueOf(dataModel.getNumber()));

                viewHolder.seats.setText(String.valueOf(dataModel.getSeats()));

                viewHolder.departureStation.setText(String.valueOf(dataModel.getDeparture_station()));

                viewHolder.destinationStation.setText(String.valueOf(dataModel.getDestination_station()));


            }

            @Override
            public int getItemCount() {
                return train_list.size();
            }
        }

    }
}