package com.app.railgo;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class SearchTrain extends AppCompatActivity {

    private Spinner departureSpinner ;

    private Spinner destinationSpinner ;

    String departureStation;
    String destinationStation;
    private List<StationDataModel> station_list ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_train);


        getSupportActionBar().setTitle("Search Train");

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        getSupportActionBar().setDisplayShowHomeEnabled(true);

        station_list = new ArrayList<>();

        departureSpinner = findViewById(R.id.departure_station_spinner);

        destinationSpinner = findViewById(R.id.destination_station_spinner);

        new MyTask().execute();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if(item.getItemId() == android.R.id.home)
        {
            finish();
        }

        return super.onOptionsItemSelected(item);
    }



    public void search_train(View view) {

         departureStation = ( (StationDataModel)departureSpinner.getSelectedItem() ).getName();

         destinationStation = ( (StationDataModel)destinationSpinner.getSelectedItem() ).getName();

         if(departureStation.equals(destinationStation)) {
             Toast.makeText(getApplicationContext(),"DEPARTURE AND DESTINATION CANNOT BE SAME SELECT DIFFERENT",Toast.LENGTH_LONG).show();
         }else{
             Intent i = new Intent(SearchTrain.this, SearchTrainResults.class);

             i.putExtra("departureStation", departureStation);
             i.putExtra("destinationStation", destinationStation);

             startActivity(i);
         }

    }



    private class MyTask extends AsyncTask<Void, Void, Void> {
        int fulluid;
        String user_status;

        public String getUser_status() {
            return user_status;
        }

        public void setUser_status(String user_status) {
            this.user_status = user_status;
        }

        public int getFulluid() {
            return fulluid;
        }

        public void setFulluid(int fulluid) {
            this.fulluid = fulluid;
        }


        @Override

        protected Void doInBackground(Void... params) {



            final JSONArray jsonArray;

            URL url = null;

            try {

                url = new URL("http://192.168.0.138:8080/railgo/webresources/generic/station" );

                HttpURLConnection client = null;

                client = (HttpURLConnection) url.openConnection();

                client.setRequestMethod("GET");

                int responseCode = client.getResponseCode();

                System.out.println("\n Sending 'GET' request to URL : " + url);

                System.out.println("Response Code : " + responseCode);

                InputStreamReader myInput = new InputStreamReader(client.getInputStream());

                BufferedReader in = new BufferedReader(myInput);
                String inputLine;
                StringBuffer response = new StringBuffer();

                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
                in.close();

                //print result
                System.out.println(response.toString());

                JSONObject obj = new JSONObject(response.toString());
                station_list.clear();
                jsonArray=obj.getJSONArray("DATA");

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        for(int i= 0; i<jsonArray.length(); i++)
                        {

                            JSONObject jsonObject = null;
                            try {
                                jsonObject = jsonArray.getJSONObject(i);
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                            StationDataModel dataModel = new StationDataModel();

                            try {
                                dataModel.setName(jsonObject.getString("name"));
                                dataModel.setLocation(jsonObject.getString("location"));
                                dataModel.setId(jsonObject.getInt("stationId"));


                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                            station_list.add(dataModel);


                        }

                        departureSpinner.setAdapter(new spinnerAdapter(SearchTrain.this , R.layout.spinner_layout , station_list));

                        destinationSpinner.setAdapter(new spinnerAdapter(SearchTrain.this , R.layout.spinner_layout , station_list));

                    }
                });



//                user_status=obj.getString("Status");
//                setUser_status(user_status);
//                int userId = obj.getInt("User_id");
//                String pass=obj.getString("Password");
//
//                //setFulluid(uid);
//                System.out.println(userId+" and password "+pass);




            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (ProtocolException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();

            }

            return null;

        }


        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);


//            System.out.println("hyyyyyyyyyyyyyyyyyyyyyyyyyy"+getUser_status());
//
//
//            if (getUser_status().equals("OK")) {
//                Intent bridge = new Intent(getApplicationContext(), UserMainActivity.class);
//
//                Toast.makeText(getApplicationContext(), "You are successfully login", Toast.LENGTH_SHORT).show();
//                startActivity(bridge);
//            } else {
//                Toast.makeText(getApplicationContext(), "PLEASE RECHECK YOUR EMAIL AND PASSWORD", Toast.LENGTH_LONG).show();
//            }
        }
    }

}
