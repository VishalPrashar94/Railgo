package com.app.railgo;

import android.provider.ContactsContract;

public class Datamodel {

    private static Datamodel datamodel=new Datamodel();
    private int user_id,booking_id;

    public int getBooking_id() {
        return booking_id;
    }

    public void setBooking_id(int booking_id) {
        this.booking_id = booking_id;
    }

    private String email;

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public static Datamodel getInstance(){
        return datamodel;
    }

    public int getUser_id() {
        return user_id;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }
}
