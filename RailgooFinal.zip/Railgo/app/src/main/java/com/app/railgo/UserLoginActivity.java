package com.app.railgo;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.util.regex.Pattern;

public class UserLoginActivity extends AppCompatActivity {


    private EditText email_et , password_et;

    private ProgressDialog pd;

    String user_type;

    String email, password;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_login);

        email_et = findViewById(R.id.email_et);

        password_et = findViewById(R.id.password_et);

        pd = new ProgressDialog(this);

        pd.setMessage("Please wait..");

        pd.setTitle("Loading");

    }

    public void do_login(View view) {

         email = email_et.getText().toString();

         password = password_et.getText().toString();

        if( ! Patterns.EMAIL_ADDRESS.matcher(email).matches() )

        {
            Toast.makeText(UserLoginActivity.this , "Please check your email syntax" , Toast.LENGTH_SHORT).show();

            return;
        }

        if( password.length() < 8 )
        {

            Toast.makeText(UserLoginActivity.this , "Password must be atleast 8 characters long" , Toast.LENGTH_SHORT).show();

            return;

        }

        new MyTask().execute();


    }



    public void signup(View view) {

        Intent i=getIntent();
        Bundle bundle=i.getExtras();
        user_type=bundle.getString("type");

        Intent in = new Intent(UserLoginActivity.this , UserSignupActivity.class);

        in.putExtra("type",user_type);
        startActivity(in);


    }


    private class MyTask extends AsyncTask<Void, Void, Void> {
        int fulluid;
        String user_status;

        public String getUser_status() {
            return user_status;
        }

        public void setUser_status(String user_status) {
            this.user_status = user_status;
        }

        public int getFulluid() {
            return fulluid;
        }

        public void setFulluid(int fulluid) {
            this.fulluid = fulluid;
        }


        @Override

        protected Void doInBackground(Void... params) {





            URL url = null;

            try {

                url = new URL("http://192.168.0.138:8080/railgo/webresources/generic/login&" + email  + "&" + password );

                HttpURLConnection client = null;

                client = (HttpURLConnection) url.openConnection();

                client.setRequestMethod("GET");

                int responseCode = client.getResponseCode();

                System.out.println("\n Sending 'GET' request to URL : " + url);

                System.out.println("Response Code : " + responseCode);

                InputStreamReader myInput = new InputStreamReader(client.getInputStream());

                BufferedReader in = new BufferedReader(myInput);
                String inputLine;
                StringBuffer response = new StringBuffer();

                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
                in.close();

                //print result
                System.out.println(response.toString());

                JSONObject obj = new JSONObject(response.toString());

                user_status=obj.getString("Status");
                setUser_status(user_status);
                int userId = obj.getInt("USER_ID");

                Datamodel datamodel=Datamodel.getInstance();

                datamodel.setUser_id(userId);

                datamodel.setEmail(obj.getString("EMAIL_ID"));


            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (ProtocolException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();

            }

            return null;

        }


        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);


            System.out.println(getUser_status()+email);


            if (getUser_status().equals("OK")) {
                Intent bridge = new Intent(getApplicationContext(), UserMainActivity.class);

                Toast.makeText(getApplicationContext(), "You are successfully login", Toast.LENGTH_SHORT).show();
                startActivity(bridge);
            } else {
                Toast.makeText(getApplicationContext(), "PLEASE RECHECK YOUR EMAIL AND PASSWORD", Toast.LENGTH_LONG).show();
            }
        }

    }


}
